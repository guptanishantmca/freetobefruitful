<?php get_header(); ?>

<main>
  <h2>Page Not Found</h2>
  <p>Oops! It seems like this page doesn't exist. Try going back to <a href="<?php echo home_url(); ?>">home</a>.</p>
</main>

<?php get_footer(); ?>
