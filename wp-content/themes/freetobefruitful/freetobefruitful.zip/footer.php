<footer class="bg-gray-100 text-center py-6 mt-10">
    <div class="container mx-auto px-4">
      <p class="text-sm text-gray-600">&copy; <?php echo date('Y'); ?> Free To Be Fruitful. All rights reserved.</p>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>