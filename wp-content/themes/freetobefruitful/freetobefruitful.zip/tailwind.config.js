module.exports = {
    content: [
      "./*.php",
      "./**/*.php",
    ],
    safelist: [
      "bg-red-50", // Just in case
      "py-20",
      "text-center",
      "container",
      "mx-auto",
      "px-4",
      "text-5xl",
      "font-bold",
      "text-blue-800",
      "mb-4",
      "text-xl",
      "text-gray-700",
      "mb-8",
      "max-w-2xl",
      "inline-block",
      "bg-blue-600",
      "text-white",
      "px-6",
      "py-3",
      "rounded-lg",
      "hover:bg-blue-700",
      "transition"
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  